Das Programm Median kann mit den folgenden Argumenten aufgerufen werden:

--load Dateiname.txt 
//L�dt Testdaten aus einer Datei

ODER

--random x
//Erzeugt x zuf�llige Zahlen

Beispiel:
Median --random 9999