#include "stdafx.h"

// Dummy class for later usage