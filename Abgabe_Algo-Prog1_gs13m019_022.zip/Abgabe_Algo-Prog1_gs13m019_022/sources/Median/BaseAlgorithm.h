#include "stdafx.h"

// This class is currently only used to group the algorithms.
// Can be used as an abstract class if the algorithms are extended. 
class BaseAlgorithm {

  };