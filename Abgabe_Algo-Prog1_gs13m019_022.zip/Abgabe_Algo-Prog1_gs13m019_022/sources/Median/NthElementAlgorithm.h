class NthElementAlgorithm : public BaseAlgorithm {
  public:
    void execute(int*, int*, int*);
	int getMedian(int* first, int* mid, int* last);	
  };