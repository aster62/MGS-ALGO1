#include "stdafx.h"

class QuickSelectAlgorithm : public BaseAlgorithm {
  public:
    int partition(int*, int, int);
	int getMedian(int*, int, int, int);
  };