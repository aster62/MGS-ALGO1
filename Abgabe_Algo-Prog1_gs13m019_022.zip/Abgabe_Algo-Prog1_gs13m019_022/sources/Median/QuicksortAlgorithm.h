#include "stdafx.h"

class QuicksortAlgorithm : public BaseAlgorithm {
  public:
    int getMedian(int*, int, int);
	void quickSort(int*, int, int);
  };