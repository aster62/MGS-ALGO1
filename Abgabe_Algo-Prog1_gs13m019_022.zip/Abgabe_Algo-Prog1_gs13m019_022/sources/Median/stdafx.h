// stdafx.h : Includedatei f�r Standardsystem-Includedateien
// oder h�ufig verwendete projektspezifische Includedateien,
// die nur in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once

#include "targetver.h"
#include "BaseAlgorithm.h"
#include "NthElementAlgorithm.h"
#include "QuickSelectAlgorithm.h"
#include "QuicksortAlgorithm.h"
#include "RandomizedSelectAlgorithm.h"
#include "ValueList.h"
#include "Timer.h"

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <sstream>

#include <stdlib.h>
#include <stdio.h>
#include <tchar.h>
#include <time.h>



// TODO: Hier auf zus�tzliche Header, die das Programm erfordert, verweisen.
